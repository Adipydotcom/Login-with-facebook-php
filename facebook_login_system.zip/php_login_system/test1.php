
<?php
session_start();
$id = $_POST['id'];
$name = $_POST['name'];
$_SESSION['fb_Id'] = $id;
$_SESSION['fb_Name'] = $name;

?>