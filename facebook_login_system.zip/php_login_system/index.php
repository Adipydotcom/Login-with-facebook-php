<?php
// unset($_COOKIE['facebook.com']);

session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Facebook Login JavaScript Example</title>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        /* style the container */
        .container {
            position: relative;
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 20px 0 30px 0;
        }

        /* style inputs and link buttons */
        input,
        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            margin: 5px 0;
            opacity: 0.85;
            display: inline-block;
            font-size: 17px;
            line-height: 20px;
            text-decoration: none;
            /* remove underline from anchors */
        }

        input:hover,
        .btn:hover {
            /* opacity: 1; */
        }

        /* add appropriate colors to fb, twitter and google buttons */
        .fb {
            background-color: #3B5998;
            color: white;
        }

        .twitter {
            background-color: #55ACEE;
            color: white;
        }

        .google {
            background-color: #dd4b39;
            color: white;
        }

        /* style the submit button */
        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            cursor: pointer;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        /* Two-column layout */
        .col {
            float: left;
            width: 50%;
            margin: auto;
            padding: 0 50px;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        /* vertical line */
        .vl {
            position: absolute;
            left: 50%;
            transform: translate(-50%);
            border: 2px solid #ddd;
            height: 175px;
        }

        /* text inside the vertical line */
        .vl-innertext {
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #f1f1f1;
            border: 1px solid #ccc;
            border-radius: 50%;
            padding: 8px 10px;
        }

        /* hide some text on medium and large screens */
        .hide-md-lg {
            display: none;
        }

        /* bottom container */
        .bottom-container {
            text-align: center;
            background-color: #666;
            border-radius: 0px 0px 4px 4px;
        }

        /* Responsive layout - when the screen is less than 650px wide, make the two columns stack on top of each other instead of next to each other */
        @media screen and (max-width: 650px) {
            .col {
                width: 100%;
                margin-top: 0;
            }

            /* hide the vertical line */
            .vl {
                display: none;
            }

            /* show the hidden text on small screens */
            .hide-md-lg {
                display: block;
                text-align: center;
            }
        }
    </style>
</head>

<body>

    <?php

    ?>

    <!-- <script>
        function statusChangeCallback(response) { // Called with the results from FB.getLoginStatus().
            console.log('statusChangeCallback');
            console.log(response); // The current login status of the person.
            if (response.status === 'connected') { // Logged into your webpage and Facebook.

                testAPI();
                // window.location.href = 'form.php';
            } else { // Not logged into your webpage or we are unable to tell.
                document.getElementById('status').innerHTML = 'Please log ' +
                    'into this webpage.';
            }
        }


        function checkLoginState() { // Called when a person is finished with the Login Button.
            FB.getLoginStatus(function(response) { // See the onlogin handler
                statusChangeCallback(response);
            });
        }


        window.fbAsyncInit = function() {
            FB.init({
                appId: '534714568635694',
                cookie: true, // Enable cookies to allow the server to access the session.
                xfbml: true, // Parse social plugins on this webpage.
                version: 'v15.0' // Use this Graph API version for this call.
            });


            FB.getLoginStatus(function(response) { // Called after the JS SDK has been initialized.
                statusChangeCallback(response); // Returns the login status.
            });
        };

        function testAPI() { // Testing Graph API after login.  See statusChangeCallback() for when this call is made.
            console.log('Welcome!  Fetching your information.... ');
            FB.login(function(response) {
                if (response.authResponse) {
                    console.log(response.authResponse.accessToken);
                    // $.ajax({
                    //     url: 'check_data.php',
                    //     type: 'post',
                    //     data: {
                    //         accessToken: response.authResponse.accessToken,
                    //     },
                    //     success: function(res) {
                    //         // alert(res);
                    //     }
                    // });
                }
            });
            FB.api('/me', function(response) {
                console.log(response);
                document.getElementById('status').innerHTML =
                    response.name + '!'
                // $.ajax({
                //     url: 'fb/post_pic.php',
                //     type: 'post',
                //     data: {
                //         name: response.name,
                //         id: response.id
                //     },
                //     success: function(result) {
                //         // alert(result);

                //     }
                // });
            });
        }
    </script> -->



    <script>
        $(document).ready(function() {
            // alert('adi');

            // Response.Cookies.Remove("www.facebook.com");

            // function getCookies() {
            //     var cookies = document.cookie.split(';');
            //     var ret = '';
            //     for (var i = 1; i <= cookies.length; i++) {
            //         ret += i + ' - ' + cookies[i - 1] + "<br>";
            //     }
            //     return ret;
            // }
            // var cook = getCookies();
            // console.log(cook);
            // document.cookie = "name=adi;max-age=0";

            const getCookie = (name) => {
                return document.cookie.split(';').some(c => {
                    return c.trim().startsWith(name + '=');
                });
            }
            const deleteCookie = (name, path, domain) => {
                if (getCookie(name)) {
                    document.cookie = name + "=" +
                        ((path) ? ";path=" + path : "") +
                        ((domain) ? ";domain=" + domain : "") +
                        ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
                }
            }
            document.cookie = 'foo=bar'
            deleteCookie('foo')
        });
        window.fbAsyncInit = function() {
            FB.init({
                appId: '534714568635694',
                cookie: true,
                xfbml: true,
                version: 'v15.0'
            });

            FB.AppEvents.logPageView();

        };

        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {
                return;
            }
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));


        function fb_login() {
            // var show = document.cookie;
            // alert(show);
            var Cookies = document.cookie.split(';');
            // alert(Cookies);
            // set 1 Jan, 1970 expiry for every cookies
            for (var i = 0; i < Cookies.length; i++)
                var show = document.cookie = Cookies[i] + "=;expires=" + new Date().toUTCString();
            // alert(show);
            FB.login(function(response) {
                // console.log(response);

                if (response.authResponse) {
                    console.log(response.authResponse);
                    fbAfterlogin();
                } else {
                    alert('You are already login... Please logout first your Facebook from currently Browser! ');
                    setTimeout(function() {

                        window.location.href = 'https://www.facebook.com';
                    }, 200)
                    // FB.logout(function(response) {
                    //     // user is now logged out
                    //     alert('User logedout ! ');
                    // });
                }
            });

        }

        function fbAfterlogin() {

            FB.getLoginStatus(function(response) {
                if (response.status === 'connected') { // Logged into your webpage and Facebook.
                    FB.api('/me', function(response) {
                        console.log(response);
                        // document.getElementById('status').innerHTML =
                        //     'Thanks for logging in, ' + response.name + '!';
                        $.ajax({
                            url: 'test1.php',
                            type: 'post',
                            data: {
                                name: response.name,
                                id: response.id
                            },
                            success: function(result) {
                                // alert(result);
                                window.location.href = 'index.php';
                            }
                        });
                    });
                } else if (response.status === 'not_authorized') {
                    alert('You are already login with outher facebook Acount! ');
                } else {
                    alert('You are already login with outher facebook Acount! ');
                }

            });
        }


        // window.location.href = 'test.php';
    </script>
    <!-- Load the JS SDK asynchronously -->
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>



    <!-- The JS SDK Login Button -->


    <!-- <button class="btn btn-success" onclick="checkLoginState()">Login</button> -->

    <?php

    ?>


    <div class="container">
        <?php
        if (isset($_SESSION['fb_Id']) && $_SESSION['fb_Id'] != '') {
        ?>
            <div class="text-center"> You are Welcome <span id="status">
                    <?php echo '' . $_SESSION['fb_Name']; ?>

                </span>

            </div>


            <form method="POST" id="data" action="" enctype="multipart/form-data">
                <!-- <div class="mb-3">
                    <label for="" class="form-label">Enter text to post Text</label>
                    <input type="text" class="form-control" name="text" id="text" placeholder="">
                </div> -->

                <div class="col-md-6">
                    <div class="col-md-12"> <?php echo $msg  ?> </div>
                    <input type="file" name="file" id="file">
                    <input type="text" name="text" id="text1">
                    <input type="text" name="text" id="text2">
                    <input type="text" name="text" id="text3">
                    <button class="btn btn-success col-md-3" id="sub_btn" type="submit">Upload Data To FB</button>
                    <!-- <button class="btn btn-success col-md-3" onclick="post_data()" type="" name="submit">Post to Facebook</button> -->
                </div>
            </form>
            <div class="mb-3 col-md-12 d-flex justify-content-center">
                <div class="col-md-3">

                    <a class="btn btn-danger col-md-3" name="logout" href="logout.php"> Logout</a>
                </div>
            </div>


    </div>
<?php
        } else {
?>

    <div class="container" style="margin-top: 8rem;">
        <div class="row">
            <div class="col-md-12">
                <!-- <div class="mb-3">
                        <div class="col-md-6">
                            <input type="file" name="img_file" id="img_file">
                        </div>
                        <button class="btn btn-success" onclick="post_data()" type="" name="submit">Post to Facebook</button>
                    </div> -->
                <div class="container">
                    <form action="/action_page.php" name="file_upload">
                        <div class="row">
                            <h2 style="text-align:center">Login with Social Media or Manually</h2>

                            <div class="vl">
                                <span class="vl-innertext">or</span>
                            </div>

                            <div class="col">
                                <a href="javascript:void(0)" onclick="fb_login()" class="fb btn">
                                    <i class="fa fa-facebook fa-fw"></i> Login with Facebook
                                </a>
                                <!-- <a class="btn btn-success">Login</a> -->

                                <a href="#" class="twitter btn">
                                    <i class="fa fa-twitter fa-fw"></i> Login with Twitter
                                </a>
                                <a href="#" class="google btn"><i class="fa fa-google fa-fw">
                                    </i> Login with Google+
                                </a>
                            </div>

                            <div class="col">
                                <div class="hide-md-lg">
                                    <p>Or sign in manually:</p>
                                </div>

                                <input type="text" name="username" placeholder="Username" required>
                                <input type="password" name="password" placeholder="Password" required>
                                <input type="submit" value="Login">
                            </div>

                        </div>
                    </form>
                </div>

                <div class="bottom-container">
                    <div class="row">
                        <div class="col">
                            <a href="#" style="color:white" class="btn">Sign up</a>
                        </div>
                        <div class="col">
                            <a href="#" style="color:white" class="btn">Forgot password?</a>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <!-- <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
    </fb:login-button> -->
    <!-- <a class="btn btn-success" scope="public_profile,email" onlogin='checkLoginState()'> Login</a> -->

<?php
        }
?>


<script>
    function post_data() {
        // var text = $('#file').val();
        var img = <?php $file_name ?>
        // console.log(img);
        $.ajax({
            url: 'fb/post_pic.php',
            type: 'post',
            data: {
                // text: text,
                img: img,
                // fid: fid,
                // name: fname

            },
            success: function(rest) {
                alert(rest);
                // window.location.href = 'index.php';
            }
        });
    }
</script>

<script>
    // $("form#data").submit(function(e) {
    //     e.preventDefault();
    // var formData = new FormData(this);
    $(document).ready(function() {
        $("#sub_btn").on('click', function(e) {
            e.preventDefault();
            var fd = new FormData();

            var files = $('#file')[0].files[0];
            fd.append('file', files);
            // $("input:text").change(function() {
            var text1 = $("#text1").val();
            fd.append('text1', text1);
            var text2 = $("#text2").val();
            fd.append('text2', text2);
            var text3 = $("#text3").val();
            fd.append('text3', text3);
            console.log(fd);
            // console.log(files);
            // console.log(text2);
            // console.log(text1);
            // console.log(text3);
            // alert(text1, text2, text3);
            // });
            $.ajax({
                url: 'fb/post_pic.php',
                type: 'post',
                data: fd,
                contentType: false,
                processData: false,
                success: function(response) {
                    alert(response);
                    if (response != 0) {
                        console.log('file uploaded');
                        window.reload();
                    } else {
                        alert('file not uploaded');
                    }
                }
            });


            // $.ajax({
            //     url: 'fb/post_pic.php',
            //     // data: formData,
            //     success: function(data) {
            //         alert(data);
            //     }
            // });


        });


    });
</script>


</body>

</html>