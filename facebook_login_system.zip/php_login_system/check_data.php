

<?php

session_start();

$con = mysqli_connect('localhost', 'dextroweb', 'Dextro20#', 'dextroweb');

$name = $_POST['name'];
$id = $_POST['id'];
$accessToken  = $_POST['accessToken'];

$res = mysqli_query($con, "SELECT * FROM fb WHERE fb_id= '$id'");
$_SESSION['fb_Id'] = $id;
$_SESSION['fb_Name'] = $name;
$_SESSION['AccessToken'] = $accessToken;

if (mysqli_num_rows($res) > 0) {
} else {
    $ins = mysqli_query($con, "INSERT into fb (fb_id, fb_name) VALUES('$id', '$name')");
}

echo $_SESSION['AccessToken'];
echo $_SESSION['fb_Id'];


?>