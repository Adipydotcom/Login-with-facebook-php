<?php

$filename = $_FILES['file']['name'];

/* Location */
$location = "./" . $filename;
$uploadOk = 1;

if ($uploadOk == 0) {
    echo 0;
} else {
    /* Upload file */
    if (move_uploaded_file($_FILES['file']['tmp_name'], $location)) {
        echo $msg = "File uploaded Successfully";
    } else {
        echo 0;
    }
}
