<?php
// session_start();

// // Include the autoloader provided in the SDK
// require_once __DIR__ . '/vendor/facebook/graph-sdk/src/Facebook/autoload.php';

// // Include required libraries
// $fb = new Facebook\Facebook([
//     'app_id' => '915022766182028',
//     'app_secret' => '6a4d26f64a3d71aabf9c3c42bb446f5d',
//     'default_graph_version' => 'v15.0',
//     'persistent_data_handler' => "session"
// ]);


// // Get redirect login helper
// $helper = $fb->getRedirectLoginHelper();

// // Try to get access token
// try {
//     $accessToken = $_SESSION['facebook_access_token'];
// } catch (Facebook\Exception\FacebookResponseException $e) {
//     echo 'Graph returned an error: ' . $e->getMessage();
//     exit;
// } catch (Facebook\Exception\FacebookSDKException $e) {
//     echo 'Facebook SDK returned an error: ' . $e->getMessage();
//     exit;
// }

// if (isset($accessToken)) {
//     $_SESSION['facebook_access_token'] = (string) $accessToken;
//     $postURL = "https://dextro.ind.in/rohit-project/dextro_b2c/php_login_system/post_photo.php";

//     echo '<a href="' . $postURL . '">Post Image on Facebook!</a>';

//     $response = $fb->get('/me?locale=en_US&fields=name,email,like', $_SESSION['facebook_access_token']);


//     $userNode = $response->getGraphNode();

//     echo '<pre>';
//     print_r($userNode);
// }

?>
<?php

session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Facebook Login JavaScript Example</title>
    <meta charset="UTF-8">

</head>

<body>
    <!-- <script>
        function statusChangeCallback(response) { // Called with the results from FB.getLoginStatus().
            console.log('statusChangeCallback');
            console.log(response); // The current login status of the person.
            if (response.status === 'connected') { // Logged into your webpage and Facebook.
                testAPI();
            } else { // Not logged into your webpage or we are unable to tell.
                document.getElementById('status').innerHTML = 'Please log ' +
                    'into this webpage.';
            }
        }


        function checkLoginState() { // Called when a person is finished with the Login Button.
            FB.getLoginStatus(function(response) { // See the onlogin handler
                statusChangeCallback(response);
            });
        }


        window.fbAsyncInit = function() {
            FB.init({
                appId: '915022766182028',
                cookie: true, // Enable cookies to allow the server to access the session.
                xfbml: true, // Parse social plugins on this webpage.
                version: 'v15.0' // Use this Graph API version for this call.
            });


            FB.getLoginStatus(function(response) { // Called after the JS SDK has been initialized.
                statusChangeCallback(response); // Returns the login status.
            });
        };

        function testAPI() { // Testing Graph API after login.  See statusChangeCallback() for when this call is made.
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me', function(response) {
                console.log('Successful login for: ' + response.name);
                document.getElementById('status').innerHTML =
                    'Thanks for logging in, ' + response.name + '!'
                $.ajax({
                    url: 'send_data.php',
                    type: 'post',
                    data: {
                        name: response.name,
                        id: response.id
                    },
                    success: function(result) {

                    }
                });
            });
        }
    </script> -->

    <script>
        window.fbAsyncInit = function() {
            FB.init({
                appId: '915022766182028',
                cookie: true,
                xfbml: true,
                version: 'v15.0'
            });

            FB.AppEvents.logPageView();

        };

        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {
                return;
            }
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));


        function fb_login() {
            FB.login(function(response) {
                if (response.authResponse) {
                    fbAfterlogin();
                }
            });
        }

        function fbAfterlogin() {

            FB.getLoginStatus(function(response) {
                if (response.status === 'connected') { // Logged into your webpage and Facebook.
                    FB.api('/me', function(response) {
                        console.log(response);
                        document.getElementById('status').innerHTML =
                            'Thanks for logging in, ' + response.name + '!';
                        $.ajax({
                            url: 'check_data.php',
                            type: 'post',
                            data: {
                                name: response.name,
                                id: response.id
                            },
                            success: function(result) {
                                alert(result);
                            }
                        });
                    });
                }

            });
        }
    </script>


    <!-- The JS SDK Login Button -->

    <?php
    // if (isset($_SESSION['fb_Id']) && $_SESSION['fb_Id'] != '') { 
    ?>
    <div id="status">
    </div>
    <!-- <a href="logout.php">Logout</a> -->
    <?php
    // } else { 
    ?>
    <button onclick="fb_login()">Login</button>
    <!-- <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
        </fb:login-button> -->
    <?php
    // } 
    ?>



    <!-- Load the JS SDK asynchronously -->
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
</body>

</html>