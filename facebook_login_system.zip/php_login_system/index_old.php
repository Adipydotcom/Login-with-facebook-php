<?php
session_start();
require_once __DIR__ .  '/vendor/facebook/graph-sdk/src/Facebook/autoload.php';

$fb = new Facebook\Facebook([
    'app_id' => '915022766182028',
    'app_secret' => '6a4d26f64a3d71aabf9c3c42bb446f5d',
    'default_graph_version' => 'v15.0',
]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email', 'user_likes', 'publish_actions']; // Optional permissions
$loginUrl = $helper->getLoginUrl('https://dextro.ind.in/rohit-project/dextro_b2c/php_login_system/login_callback.php', $permissions);

echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';
