<?php
require_once __DIR__ . '/vendor/autoload.php';

session_start();

$fb = new Facebook\Facebook([
    'app_id' => '915022766182028',
    'app_secret' => '6a4d26f64a3d71aabf9c3c42bb446f5d',
    'default_graph_version' => 'v8.0',
]);

$helper = $fb->getRedirectLoginHelper();


if (isset($_GET['code'])) {


    if (isset($_SESSION['accessToken'])) {
        $accessToken = $_SESSION['accessToken'];
    } else {
        $accessToken = $helper->getAccessToken();
        $_SESSION['accessToken'] = $accessToken;
        $fb->setDefaultAccessToken($_SESSION['accessToken']);
    }

    $_SESSION['user_name'] = '';
    $_SESSION['user_email_address'] = '';
    $graph_responce = $fb->get("/me?fields=name,email", $accessToken);

    $facebook_user_info = $graph_responce->getGraphUser;

    $_SESSION['user_name'] = $facebook_user_info['name'];
    $_SESSION['user_email_address'] = $facebook_user_info['email'];

    $requestPicture = $fb->get("/me/picture?redirect=false&height=150", $accessToken);
    $fbPic = $requestPicture->getGraphUser;
    $_SESSION['pro_pic'] = $fbPic;
} else {

    $permissions = ['email']; // Optional permissions
    $loginUrl = $helper->getLoginUrl('http://localhost/php_login_system/', $permissions);
}
