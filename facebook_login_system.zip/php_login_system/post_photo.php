<?php
session_start();
require_once __DIR__ . '/vendor/facebook/graph-sdk/src/Facebook/autoload.php';


$fb = new Facebook\Facebook([
    'app_id' => '915022766182028',
    'app_secret' => '6a4d26f64a3d71aabf9c3c42bb446f5d',
    'default_graph_version' => 'v15.0',
]);

$data = [
    'message' => 'My image caption',
    'source' => $fb->fileToUpload('image.jfif'),
];

try {
    // Returns a `Facebook\FacebookResponse` object
    $response = $fb->post('/me/photos', $data, $_SESSION['facebook_access_token']);
} catch (Facebook\Exception\ResponseException $e) {
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (Facebook\Exception\FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

$graphNode = $response->getGraphNode();

echo 'Photo ID: ' . $graphNode['id'];
