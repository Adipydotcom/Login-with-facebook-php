<?php
session_start();
require_once __DIR__ . '/vendor/autoload.php';


$fb = new Facebook\Facebook([
    'app_id' => '915022766182028',
    'app_secret' => '6a4d26f64a3d71aabf9c3c42bb446f5d',
    'default_graph_version' => 'v15.0',
    'persistent_data_handler' => "session"
]);

$linkdata = [
    'link' => 'https://example.com/',
    'message' => 'Hello bot! My name is Aditya',
];

try {
    // Returns a `Facebook\FacebookResponse` object
    $response = $fb->post('/me/feed', $linkdata, $_SESSION['facebook_access_token']);
} catch (Facebook\Exceptions\FacebookResponseException $e) {
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

$graphNode = $response->getGraphNode();

echo 'Post ID: ' . $graphNode['id'];
