<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>After login page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
    <!-- Form area -->

    <div class="container">
        <div class="col-md-12">
            Welcome <?php echo $_POST['name']; ?>
        </div>
        <form action="" method="post">
            <div class="mb-3">
                <label for="" class="form-label">Enter text to post Text</label>
                <input type="text" class="form-control" name="text" id="text" placeholder="">
            </div>

            <!-- <div class="mb-3">
                <label for="" class="form-label">Enter text to post Text</label>
                <input type="text" class="form-control" name="text" id="text" placeholder="">
            </div> -->

            <div class="mb-3">

                <button class="btn btn-success" type="submit" name="submit">Post to Facebook</button>
            </div>
        </form>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>


    <script>
        var text = $('#text').val();
        $.ajax({
            url: 'fb/post.php',
            type: 'post',
            data: {
                text: text
            },
            success: function(rest) {
                alert('data posted');
            }
        })
    </script>




    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
</body>

</html>