<?php
session_start();

$data = '';

if (isset($data)) {
    // Upload File Here
    $filename = $_FILES['file']['name'];
    $location = "../" . $filename;
    $uploadOk = 1;
    if ($uploadOk == 0) {
        echo 0;
    } else {
        /* Upload file */
        if (move_uploaded_file($_FILES['file']['tmp_name'], $location)) {
            echo "File uploaded Successfully";
        } else {
            echo 0;
        }
    }
} else {
    echo 'Error';
}


$_POST['text1'];


$accessToken =  $_POST['accessToken'];
// $id = $_POST['fid'];
// $name = $_POST['fname'];
// echo $_SESSION['fb_Id'] = $id;
// $_SESSION['fb_Name'] = $name;
require('./src/Facebook/autoload.php');


$fb = new Facebook\Facebook([
    'app_id' => '534714568635694',
    'app_secret' => '55ff9d22fa4b8f25019d6511df7d3baa',
    'default_graph_version' => 'v2.10',
]);

$textdat1 = $_POST['text1'];
$textdat1 = $_POST['text2'];
$textdat3 = $_POST['text3'];

$data = [
    'message' => "$textdat1.'<br>' $textdat1.'<br>' $textdat3",
    'link' => 'http://www.example.com',
    'source' => $fb->fileToUpload("../{$filename}"),
];



$data1 = [
    'message' => $textdat,
];


try {
    // Returns a `Facebook\FacebookResponse` object
    $response = $fb->post('/me/photos', $data, 'EAAHmUeZCrdS4BAHV4gKwAVpP8gvRr8pxEDMGZAZCmgGL2znGETYcW3j3MZCPL2ZAJt7sWo7DVFJZCQY6ymWKj22LHGaGTKvAqAlj6ZCcwELVEs2NYEZCBqsgHFxWxV41D5Bs1UPK3W8lqZCFwLwx6FDfo2icdntpBmNZCfwaoAGy26VJYCdX668EmVeVdScZCk7Dwo9NcfgnYFgBwZDZD');

    // $response = $fb->post('/me/feed', $data1, 'EAAHmUeZCrdS4BABWu3kLYKiSDFPI5ZC1COQgwIpORhArmgavWXQ6R6r36Ik6h0HwL21sgm4qfyT6W9npqww2SkVjRE9kOjRgZAHCpUzsj4QSDa32ZByS5bhwl1QXc1Tj7r57Hy9jqfF6crazM6UzimivaXSJrNVe9VjYi5I3eCj1GJB9KYFvcZAI0gseteV4ZD');
} catch (Facebook\Exceptions\FacebookResponseException $e) {
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

$graphNode = $response->getGraphNode();
// echo 'Posted with id: ' . $graphNode['id'];
echo 'Post Uploaded';
