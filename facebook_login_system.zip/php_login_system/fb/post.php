<?php
session_start();

$accessToken =  $_POST['accessToken'];
$textdat = $_POST['text'];

$id = $_POST['id'];
$name = $_POST['name'];
$_SESSION['fb_Id'] = $id;
$_SESSION['fb_Name'] = $name;
require('./src/Facebook/autoload.php');


$fb = new Facebook\Facebook([
  'app_id' => '534714568635694',
  'app_secret' => '55ff9d22fa4b8f25019d6511df7d3baa',
  'default_graph_version' => 'v2.10',
]);

// $data1 = [
//   'message' => 'Testing Pic',
//   'link' => 'http://www.example.com',
//   'source' => $fb->fileToUpload('./src/Facebook-logo.png'),
// ];

$data = [
  'message' => $textdat,
];


try {
  // Returns a `Facebook\FacebookResponse` object
  $response = $fb->post('/me/feed', $data, 'EAAHmUeZCrdS4BABWu3kLYKiSDFPI5ZC1COQgwIpORhArmgavWXQ6R6r36Ik6h0HwL21sgm4qfyT6W9npqww2SkVjRE9kOjRgZAHCpUzsj4QSDa32ZByS5bhwl1QXc1Tj7r57Hy9jqfF6crazM6UzimivaXSJrNVe9VjYi5I3eCj1GJB9KYFvcZAI0gseteV4ZD');
} catch (Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch (Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$graphNode = $response->getGraphNode();

echo 'Posted with id: ' . $graphNode['id'];
